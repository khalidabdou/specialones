package com.reccakun.clientappiptv.Controllers;

public class Const {


    public static boolean imageCatEnable=true;
    public static boolean imageListEnable=true;



}
