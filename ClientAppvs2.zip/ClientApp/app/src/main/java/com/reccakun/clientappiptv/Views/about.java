package com.reccakun.clientappiptv.Views;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.reccakun.clientappiptv.R;
public class about extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }
}
