package com.stickers_love.wastickerapps_whatsapp_mrbean_messenger_bean_funny_emoji.model;

public class objectFirebase {

    public static String admob_banner;
    public static String admob_interstitial;
    public  static String fb_banner;
    public static String fb_intrestitial;

    public objectFirebase(){}
    public objectFirebase(String admob_banner, String admob_interstitial, String fb_banner, String fb_intrestitial) {
        this.admob_banner = admob_banner;
        this.admob_interstitial = admob_interstitial;
        this.fb_banner = fb_banner;
        this.fb_intrestitial = fb_intrestitial;
    }

    public String getAdmob_banner() {
        return admob_banner;
    }

    public String getAdmob_interstitial() {
        return admob_interstitial;
    }

    public String getFb_banner() {
        return fb_banner;
    }

    public String getFb_intrestitial() {
        return fb_intrestitial;
    }
}
