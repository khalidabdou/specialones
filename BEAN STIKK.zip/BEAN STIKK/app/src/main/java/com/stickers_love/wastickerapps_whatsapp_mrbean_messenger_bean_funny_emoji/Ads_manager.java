package com.stickers_love.wastickerapps_whatsapp_mrbean_messenger_bean_funny_emoji;

import android.content.Context;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.stickers_love.wastickerapps_whatsapp_mrbean_messenger_bean_funny_emoji.model.objectFirebase;

import java.io.ObjectStreamField;
import java.util.concurrent.Executor;


public class Ads_manager {
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    public static  objectFirebase obj;

    private AdmobAdsClass admobAdsClass=new AdmobAdsClass();
    private facebookAdsClass facebookAdsClass=new facebookAdsClass();




    public void checkAndBuild(LinearLayout mAdView,Context context){
        obj=new objectFirebase();
        DocumentReference ref=db.collection("ads").document("obj");
        ref.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()){
                    DocumentSnapshot documentSnapshot=task.getResult();
                    if (documentSnapshot!=null){
                        obj=documentSnapshot.toObject(objectFirebase.class);
                        mAdView.addView(facebookAdsClass.fbLoadBanner(context,obj.getFb_banner()));
                        mAdView.addView(admobAdsClass.loadBannerads(context,obj.getAdmob_banner()));
                        objectFirebase.admob_interstitial=obj.getAdmob_interstitial();
                        objectFirebase.fb_intrestitial=obj.getFb_intrestitial();
                       //Toast.makeText(context, obj.getFb_banner(), Toast.LENGTH_SHORT).show();

                    }
                }


            }
        });






    }

    public objectFirebase fb_interstitial(Context context){
        obj=new objectFirebase();
        DocumentReference ref=db.collection("ads").document("obj");
        ref.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()){
                    DocumentSnapshot documentSnapshot=task.getResult();
                    if (documentSnapshot!=null){
                        obj=documentSnapshot.toObject(objectFirebase.class);
                       // Toast.makeText(context, obj.fb_intrestitial, Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });
        return obj;
    }


}
