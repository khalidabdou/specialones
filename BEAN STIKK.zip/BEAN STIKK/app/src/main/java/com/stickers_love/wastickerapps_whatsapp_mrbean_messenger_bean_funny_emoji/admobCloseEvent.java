package com.stickers_love.wastickerapps_whatsapp_mrbean_messenger_bean_funny_emoji;

public interface admobCloseEvent {
    public void setAdmobCloseEvent();
}