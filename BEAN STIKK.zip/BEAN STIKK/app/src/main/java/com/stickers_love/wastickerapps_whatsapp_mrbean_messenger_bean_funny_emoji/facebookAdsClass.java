package com.stickers_love.wastickerapps_whatsapp_mrbean_messenger_bean_funny_emoji;
import android.content.Context;
import android.os.Debug;
import android.util.Log;
import android.widget.Toast;

import com.facebook.ads.*;
public class facebookAdsClass {



    public AdView fbLoadBanner(Context context,String id){
        AdView adView= new AdView(context, id, AdSize.BANNER_HEIGHT_50);
        adView.loadAd();

        return adView ;
    }


    public InterstitialAd loadinterstitial(Context context ,InterstitialAd interstitialAd){

        interstitialAd.loadAd();
        AdSettings.addTestDevice("fbc7940c-a204-40b4-8578-88883a7cb150");
        //Toast.makeText(context, EntryActivity.objectFirebase.fb_banner, Toast.LENGTH_SHORT).show();

           /* interstitialAd.loadAd();
            Toast.makeText(context, "isloaded", Toast.LENGTH_SHORT).show();*/
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
                // Interstitial ad displayed callback
               // Toast.makeText(context, "onInterstitialDisplayed", Toast.LENGTH_SHORT).show();


            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                // Interstitial dismissed callback
                //keText(context, "onInterstitialDismissed", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onError(Ad ad, AdError adError) {
               // Toast.makeText(context, "onError", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                //Toast.makeText(context, "onAdLoaded", Toast.LENGTH_SHORT).show();
                interstitialAd.show();
            }

            @Override
            public void onAdClicked(Ad ad) {
               // Toast.makeText(context, "onAdClicked", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                //Toast.makeText(context, "onLoggingImpression", Toast.LENGTH_SHORT).show();
            }
        });



        return interstitialAd;

    }



    public void ShowInterstitial(InterstitialAd interstitialAd)
    {


    }
}
