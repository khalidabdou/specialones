package com.example.nikola.callblockingtestdemo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.androidquery.AQuery;
import com.androidquery.callback.AjaxStatus;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_READ_PHONE_STATE = 1;
    public static Context mContext;
    public static int index = 0;
    public static boolean isCallInApp = false;
    public static List<number> listNumbers = new ArrayList<>();
    public static List<JSONObject> jsonDelete = new ArrayList<>();
    public AQuery aq;
    public String url = "https://skandev.com/appCall/getData.php";
    public String send = "https://skandev.com/appCall/deleteData.php";
    Button btCall;
    mangerCalls mangerCalls;

    // delet from database
    public static void iscalled(int id) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("success", 0);
            jsonObject.put("message", MainActivity.listNumbers.get(id).id);
            jsonDelete.add(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public static void deleteFromDB() {
        for (int i = 0; i < jsonDelete.size(); i++) {
            Toast.makeText(mContext, jsonDelete.get(i).toString(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;
        aq = new AQuery(mContext);
        mangerCalls = new mangerCalls();

        btCall = findViewById(R.id.btcall);
        listNumbers.clear();
        aq.ajax(url, JSONArray.class, this, "jsonCallback");


        btCall.setEnabled(false);
        btCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mangerCalls.startNewCall(mContext);
                isCallInApp = true;
            }
        });

        Toast.makeText(this, "Started the app", Toast.LENGTH_SHORT).show();

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_DENIED || checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_DENIED) {
                String[] permissions = {Manifest.permission.READ_PHONE_STATE, Manifest.permission.CALL_PHONE};
                requestPermissions(permissions, PERMISSION_REQUEST_READ_PHONE_STATE);
            }
        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_READ_PHONE_STATE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission granted: " + PERMISSION_REQUEST_READ_PHONE_STATE, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission NOT granted: " + PERMISSION_REQUEST_READ_PHONE_STATE, Toast.LENGTH_SHORT).show();
                }

                return;
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();

    }

    // read json and put numbres in list
    public void jsonCallback(String url, JSONArray json, AjaxStatus status) {

        try {
            for (int i = 0; i < json.length(); i++) {
                if (json.getJSONObject(i).getString("isCalled").equals("0")) {
                    // todo :
                    String nbr = "0923" + json.getJSONObject(i).getString("num") + "9";
                    String id = json.getJSONObject(i).getString("id");
                    listNumbers.add(new number(nbr, id));

                }
                // Toast.makeText(mContext, json.getJSONObject(i).getString("num"), Toast.LENGTH_SHORT).show();
            }
            btCall.setEnabled(true);

        } catch (JSONException e) {
            e.printStackTrace();
            btCall.setEnabled(false);
        }


    }

}
