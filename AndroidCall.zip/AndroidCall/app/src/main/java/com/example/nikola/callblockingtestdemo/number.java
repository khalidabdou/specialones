package com.example.nikola.callblockingtestdemo;

public class number {
    public String number;
    public String id;

    public number(String number, String id) {
        this.number = number;
        this.id = id;
    }
}
