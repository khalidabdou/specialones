package com.example.nikola.callblockingtestdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import com.android.internal.telephony.ITelephony;

import java.lang.reflect.Method;

public class IncomingCallReceiver extends BroadcastReceiver {
    mangerCalls mangerCalls = new mangerCalls();

    @Override
    public void onReceive(final Context context, Intent intent) {

        if (!MainActivity.isCallInApp) {
            Toast.makeText(context, "return", Toast.LENGTH_SHORT).show();
            return;
        }
        ITelephony telephonyService;
        try {
            String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
            String number = intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
            Toast.makeText(context, state, Toast.LENGTH_SHORT).show();
            if (state.equalsIgnoreCase(TelephonyManager.EXTRA_STATE_RINGING)) {
                //Toast.makeText(context, "Ring " + number, Toast.LENGTH_SHORT).show();
            }
            if (state.equalsIgnoreCase(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                // Toast.makeText(context, "Answered " + number, Toast.LENGTH_SHORT).show();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        cancel(context);
                    }
                }, 5000);
            }
            if (state.equalsIgnoreCase(TelephonyManager.EXTRA_STATE_IDLE)) {
                Toast.makeText(context, "Idle " + number, Toast.LENGTH_SHORT).show();
                MainActivity.iscalled(MainActivity.index);
                mangerCalls.startNewCall(context);
                if (MainActivity.listNumbers.size() == MainActivity.index)
                    MainActivity.deleteFromDB();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void cancel(Context context) {
        ITelephony telephonyService;
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        try {
            Method m = tm.getClass().getDeclaredMethod("getITelephony");
            m.setAccessible(true);
            telephonyService = (ITelephony) m.invoke(tm);
            telephonyService.endCall();
            //Toast.makeText(context, "Ending the call from: " , Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
