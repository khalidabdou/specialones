package com.example.nikola.callblockingtestdemo;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;

public class mangerCalls {

    // list of nambres


    //start next call
    public void startNewCall(Context context) {


        try {
            Intent intent = new Intent(Intent.ACTION_CALL, Uri.fromParts("tel", indexTel(MainActivity.index), null));
            context.startActivity(intent);
            MainActivity.index++;
        } catch (Exception ex) {
        }

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
    }

    //get numbre by index
    public String indexTel(int index) {
        return MainActivity.listNumbers.get(index).number;
    }


}
